from django.shortcuts import render
from django.views import View
from . import models
from django import http
from meiduo_mall.utils.response_code import RETCODE
from django.core.cache import cache

class AreasView(View):
    def get(self,request):
        area_id = request.GET.get('area_id')
        if area_id:
            # 提供市区数据
            sub_data = cache.get('sub_area_' + area_id)
            if not sub_data:
                try:
                    sub_model_list = models.Area.objects.filter(parent_id=area_id)
                    parent_model = models.Area.objects.get(id = area_id)
                    # sub_model_list = parent_model.subs.all()
                    sub_list = [{'id':i.id,'name':i.name} for i in sub_model_list]
                except Exception as e:
                    print(e)
                    return http.JsonResponse({'code': '5000', 'errmsg': '城市或区数据错误'})
                # 序列化数据
                sub_data = {
                    'id': parent_model.id,  # 父级pk
                    'name': parent_model.name,  # 父级name
                    'subs': sub_list  # 父级的子集
                }
                cache.set('sub_area_' + area_id, sub_data, 3600)
            else:
                print('从缓存中读取市区数据')
            return http.JsonResponse({'code': '0', 'errmsg': 'OK', 'sub_data': sub_data})


        else:
            # 提供省份数据
            province_list = cache.get('province_list')
            if not province_list:
                try:
                    province_model_list = models.Area.objects.filter(parent_id__isnull = True)
                    province_list = [{'id':p.id,'name':p.name} for p in province_model_list]
                except Exception as e:
                    print(e)
                    return http.JsonResponse({'code': '5000', 'errmsg': '城市或区数据错误'})
                # 存入缓存
                cache.set('province_list', province_list, 3600)
            else:
                print('从缓存中读取省数据')
            return http.JsonResponse({'code': '0', 'errmsg': 'OK', 'province_list': province_list})



