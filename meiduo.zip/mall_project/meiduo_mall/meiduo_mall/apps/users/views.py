import json
import re
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views import View
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.db import DatabaseError
from .models import User
from django.shortcuts import redirect,reverse
from django.contrib.auth import login,logout,authenticate
from django import http
from django_redis import get_redis_connection
from meiduo_mall.utils.response_code import *
from .models import User,Address
from . import utils
from django.core.mail import send_mail
from django.conf import settings
from meiduo_mall.settings import dev
import logging

logger = logging.getLogger('django')


class RegisterView(View):
    def get(self, requests):
        return render(requests,'register.html')

    def post(self, request):
        '''
        接收前端的参数

        '''
        # 接收参数：表单参数
        username = request.POST.get('username')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        mobile = request.POST.get('mobile')
        sms_code_client = request.POST.get('sms_code')
        allow = request.POST.get('allow')

        # 判断两次密码是否一致
        if password != password2:
            return http.HttpResponseForbidden('两次输入的密码不一致')

        # 判断短信验证码是否输入正确
        redis_conn = get_redis_connection('verify_code')
        sms_code_server = redis_conn.get('sms_%s' % mobile)
        if sms_code_server is None:
            return render(request, 'register.html', {'sms_code_errmsg': '短信验证码已失效'})
        if sms_code_client != sms_code_server.decode():
            return render(request, 'register.html', {'sms_code_errmsg': '输入短信验证码有误'})
        # 判断是否勾选用户协议
        if allow != 'on':
            return http.HttpResponseForbidden('请勾选用户协议')
        # 保存如数据库
        try:
            user = User.objects.create_user(username=username, password=password, mobile=mobile)
        except DatabaseError:  # 如果链接数据库失败
            return render(request, 'register.html', {'register_errmsg': '注册失败'})
        login(request,user)
        # 响应注册结果
        return redirect(reverse('contents:index'))


class UsernameCountView(View):
    '''判断用户名是否重复'''
    def get(self,request,username):
        count = User.objects.filter(username=username).count()
        return JsonResponse({'code':RETCODE.OK,'errmsg': 'OK', 'count': count})


class MobileCountView(View):
    '''判断手机号是否重复'''
    def get(self,request,mobile):
        count = User.objects.filter(mobile=mobile).count()
        return JsonResponse({'code':RETCODE.OK,'errmsg': 'OK', 'count': count})

class LogView(View):
    def get(self,request):
        return render(request,'login.html')
    def post(self,request):
        # 接受参数
        username = request.POST.get('username')
        password = request.POST.get('password')
        remembered = request.POST.get('remembered')
        if not all([username,password]):
            return HttpResponseForbidden('缺少必要参数')
        # 用authenticate校验
        user = authenticate(username=username,password=password)
        if not user:
            return render(request, 'login.html', {'register_errmsg': '用户名或密码错误'})
        # 状态保持
        login(request,user)
        # 设置状态保持的周期
        if remembered != 'on':
            # 没有记住用户：浏览器会话结束就过期
            request.session.set_expiry(0)
        else:
            # 记住用户：None表示两周后过期
            request.session.set_expiry(None)

        # 响应登录结果
        return redirect(reverse('contents:index'))

class LogoutView(View):
    """退出登录"""
    def get(self, request):
        """实现退出登录逻辑"""
        # 清理session
        logout(request)
        # 退出登录，重定向到登录页
        response = redirect(reverse('contents:index'))
        # 退出登录时清除cookie中的username
        response.delete_cookie('username')

        return response

# class UserInfoView(View):
#     """用户中心"""
#
#     def get(self, request):
#         """提供个人信息界面"""
#         if request.user.is_authenticated():
#             return render(request, 'user_center_info.html')
#         else:
#             # request.path 返回当前路径，不包括域名
#             path = reverse('users:login')+'?next='+request.path
#             return redirect(path)


# class UserInfoView(View):
#     """用户中心"""
#
#     def get(self, request):
#         """提供个人信息界面"""
#         if request.user.is_authenticated():
#             return render(request, 'user_center_info.html')
#         else:
#             # request.path 返回当前路径，不包括域名
#             path = reverse('users:login')+'?next='+request.path
#             return redirect(path)

class UserInfoView(LoginRequiredMixin,View):
    '''用户中心'''
    def get(self,request):
        context = {
            'username': request.user.username,
            'mobile': request.user.mobile,
            'email': request.user.email,
            'email_active': request.user.email_active
        }
        return render(request, 'user_center_info.html',context = context)


class EmailView(LoginRequiredMixin,View):
    '''添加邮箱'''
    def put(self,request):
        # 接受参数
        json_dic = json.loads(request.body.decode())
        email = json_dic.get('email')
        # 对邮箱进行判断
        if not email:
            return HttpResponseForbidden('缺少必要参数')
        if not re.match(r'^[a-z0-9_][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$',email):
            return HttpResponseForbidden('邮箱格式错误')
        # 赋值email字段
        try:
            request.user.email = email
            request.user.save()
        except:
            return http.JsonResponse({'code': RETCODE.DBERR, 'errmsg': '添加邮箱失败'})
        verify_url = utils.generate_verify_email_url(request.user)
        subject = "美多商城邮箱验证"
        html_message = '<p>尊敬的用户您好！</p>' \
                       '<p>感谢您使用美多商城。</p>' \
                       '<p>您的邮箱为：%s 。请点击此链接激活您的邮箱：</p>' \
                       '<p><a href="%s">%s<a></p>' % (email, verify_url, verify_url)
        res = send_mail(subject, "", dev.EMAIL_FROM, [email], html_message=html_message,
                        auth_user=dev.EMAIL_HOST_USER, auth_password=settings.EMAIL_HOST_PASSWORD, )
        print(res)
        return http.JsonResponse({'code':RETCODE.OK, 'errmsg': '添加邮箱成功'})

class VerifyEmailView(View):
    """验证邮箱"""

    def get(self, request):
        """实现邮箱验证逻辑"""
        # 接收参数
        token = request.GET.get('token')

        # 校验参数：判断token是否为空和过期，提取user
        if not token:
            return http.HttpResponseBadRequest('缺少token')

        user = utils.check_verify_email_token(token)
        if not user:
            return http.HttpResponseForbidden('无效的token')

        # 修改email_active的值为True
        try:
            user.email_active = True
            user.save()
        except Exception as e:
            return http.HttpResponseServerError('激活邮件失败')

        # 返回邮箱验证结果
        return redirect(reverse('user:info'))

class AddressView(LoginRequiredMixin, View):
    """用户收货地址"""

    def get(self, request):
        """提供收货地址界面"""

        return render(request, 'user_center_site.html')

from . import models
class CreateAddressView(LoginRequiredMixin, View):
    '''
    添加用户收货地址
    '''
    def post(self,request):
        # 判断是否超上线，最多２０
        count = request.user.addresses.count()
        if count >= 20:
            return http.JsonResponse({'code': '4002', 'errmsg': '超过地址数量上限'})
            # 接收参数
        json_str = request.body.decode()
        json_dict = json.loads(json_str)
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')
        # 校验参数
        if not all([receiver, province_id, city_id, district_id, place, mobile]):
            return http.HttpResponseForbidden('缺少必传参数')
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return http.HttpResponseForbidden('参数mobile有误')
        if email:
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                return http.HttpResponseForbidden('参数email有误')
        try:
            address = models.Address.objects.create(
                user=request.user,
                title=receiver,
                receiver=receiver,
                province_id=province_id,
                city_id=city_id,
                district_id=district_id,
                place=place,
                mobile=mobile,
                tel=tel,
                email=email
            )

            # 设置默认地址
            if not request.user.default_address:
                request.user.default_address = address
                request.user.save()
        except Exception as e:
            print(e)
            return http.JsonResponse({'code': RETCODE.DBERR, 'errmsg': '新增地址失败'})
            # 新增地址成功，将新增的地址响应给前端实现局部刷新
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
                       }
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '新增地址成功', 'address': address_dict})




class AddressView(LoginRequiredMixin, View):
    """用户收货地址"""

    def get(self, request):
        """提供收货地址界面"""
        # 获取当前登录用户对象
        login_user = request.user
        # 使用当前登录用户和is_deleted=False作为条件查询地址数据
        # 两种方法都可以
        addresses = Address.objects.filter(user=login_user,is_deleted=False)
        addresses = login_user.addresses.filter(is_deleted=False)
        # 将用户地址模型列表转字典列表:因为JsonResponse和Vue.js不认识模型类型，只有Django和Jinja2模板引擎认识
        address_list = []
        for address in addresses:
            address_dict = {
                "id": address.id,
                "title": address.title,
                "receiver": address.receiver,
                "province": address.province.name,
                "city": address.city.name,
                "district": address.district.name,
                "place": address.place,
                "mobile": address.mobile,
                "tel": address.tel,
                "email": address.email
            }
            address_list.append(address_dict)
        context = {
            'default_address_id': login_user.default_address_id or '0',  # 没有默认地址 None
            'addresses': address_list
        }
        return render(request, 'user_center_site.html',context=context)

class UpdateDestroyAddressView(View):
    """修改和删除地址"""

    def put(self, request, address_id):
        """修改地址"""
        # 接收参数
        json_dict = json.loads(request.body.decode())
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')

        # 校验参数
        if not all([receiver, province_id, city_id, district_id, place, mobile]):
            return http.HttpResponseForbidden('缺少必传参数')
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return http.HttpResponseForbidden('参数mobile有误')
        if email:
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                return http.HttpResponseForbidden('参数email有误')

        # 判断地址是否存在,并更新地址信息
        try:
            Address.objects.filter(id=address_id).update(
                user = request.user,
                title = receiver,
                receiver = receiver,
                province_id = province_id,
                city_id = city_id,
                district_id = district_id,
                place = place,
                mobile = mobile,
                tel = tel,
                email = email
            )
        except Exception as e:
            logger.error(e)
            return http.JsonResponse({'code': RETCODE.DBERR, 'errmsg': '更新地址失败'})

        # 构造响应数据
        address = Address.objects.get(id=address_id)
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
        }

        # 响应更新地址结果
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '更新地址成功', 'address': address_dict})

    def delete(self, request, address_id):
        """删除地址"""
        try:
            # 查询要删除的地址
            address = models.Address.objects.get(id=address_id)

            # 将地址逻辑删除设置为True
            address.is_deleted = True
            address.save()
        except Exception as e:
            print(e)
            return http.JsonResponse({'code': '5000', 'errmsg': '删除地址失败'})

        # 响应删除地址结果
        return http.JsonResponse({'code': '0', 'errmsg': '删除地址成功'})

class DefaultAddressView(LoginRequiredMixin, View):
    """设置默认地址"""

    def put(self, request, address_id):
        """设置默认地址"""
        try:
            # 接收参数,查询地址
            address = models.Address.objects.get(id=address_id)

            # 设置地址为默认地址
            request.user.default_address = address
            request.user.save()
        except Exception as e:
            print(e)
            return http.JsonResponse({'code': '5000', 'errmsg': '设置默认地址失败'})

        # 响应设置默认地址结果
        return http.JsonResponse({'code': '0', 'errmsg': '设置默认地址成功'})

class UpdateTitleAddressView(LoginRequiredMixin, View):
    """设置地址标题"""

    def put(self, request, address_id):
        """设置地址标题"""
        # 接收参数：地址标题
        json_dict = json.loads(request.body.decode())
        title = json_dict.get('title')

        try:
            # 查询地址
            address = models.Address.objects.get(id=address_id)

            # 设置新的地址标题
            address.title = title
            address.save()
        except Exception as e:
            print(e)
            return http.JsonResponse({'code': '5000', 'errmsg': '设置地址标题失败'})

        # 4.响应删除地址结果
        return http.JsonResponse({'code': '0', 'errmsg': '设置地址标题成功'})