# _*_coding:utf-8 _*_

from django.contrib.auth.backends import ModelBackend
import re
from users.models import User


def get_user_by_account(account):
    """
    根据account查询用户
    :param account: 用户名或者手机号
    :return: user
    """
    try:
        if re.match('^1[3-9]\d{9}$', account):
            # 手机号登录
            user = User.objects.get(mobile=account)
        else:
            # 用户名登录
            user = User.objects.get(username=account)
    except User.DoesNotExist:
        return None
    else:
        return user


class UsernameMobileAuthBackend(ModelBackend):
    """自定义用户认证后端"""

    def authenticate(self, request, username=None, password=None, **kwargs):
        """
        重写认证方法，实现多账号登录
        :param request: 请求对象
        :param username: 用户名
        :param password: 密码
        :param kwargs: 其他参数
        :return: user
        """
        # 根据传入的username获取user对象。username可以是手机号也可以是账号
        user = get_user_by_account(username)
        # 校验user是否存在并校验密码是否正确
        if user and user.check_password(password):
            return user

from itsdangerous import TimedJSONWebSignatureSerializer as serializer
from django.conf import settings
from meiduo_mall.utils.constants import VERIFY_EMAIL_TOKEN_EXPIRES


def generate_verify_email_url(user):
    '''
    :param user: requests.user
    :return: 邮箱验证地址
    '''
    t = serializer(settings.SECRET_KEY, expires_in=VERIFY_EMAIL_TOKEN_EXPIRES)  # 过期时间600s
    info = {
        'user_name': user.username,
        'id': user.id
    }
    res = t.dumps(info)
    token = res.decode()
    verify_url = settings.EMAIL_VERIFY_URL + '?token=' + token
    return verify_url

from itsdangerous import BadData
def check_verify_email_token(token):
    '''
    :param token: 令牌字符串
    :return: ORM user对象
    '''
    s = serializer(settings.SECRET_KEY, expires_in=VERIFY_EMAIL_TOKEN_EXPIRES)

    try:
        data = s.loads(token)
    except BadData:
        return None
    user_id  = data.get('id')
    user_name = data.get('user_name')
    try:
        user = User.objects.get(id=user_id,username = user_name)
    except User.DoesNotExist:
        return None
    return user