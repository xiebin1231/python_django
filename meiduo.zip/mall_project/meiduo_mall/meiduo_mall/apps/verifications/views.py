from django.views import View
from .lib.captcha.captcha import captcha
from django_redis import get_redis_connection
from django import http
from meiduo_mall.utils import constants
from meiduo_mall.utils.response_code import RETCODE
import random
from .lib.yuntongxun.ccp_sms import CCP
import logging
logger = logging.getLogger('django')


# Create your views here.
class ImageCodeView(View):
    def get(self, request, uuid):
        """
        :param request: 请求对象
        :param uuid: 唯一标识图形验证码所属于的用户
        :return: image/jpg

        """
        # 获取到验证码的文字和图片
        text, img = captcha.generate_captcha()
        # 与ｒｅｄｉｓ数据库交互
        redis_conn = get_redis_connection('verify_code')
        # 设置过期时间３００秒
        redis_conn.setex('img_%s' % uuid, 300, text)
        return http.HttpResponse(img, content_type='image/jpg')

class SMSCodeView(View):
    """短信验证码"""

    def get(self, reqeust, mobile):
        """
        :param reqeust: 请求对象
        :param mobile: 手机号
        :return: JSON
        """
        # 获取参数
        image_code_client = reqeust.GET.get('image_code')
        uuid = reqeust.GET.get('uuid')
        # 校验参数
        if not all([image_code_client, uuid]):
            return http.JsonResponse({'code': RETCODE.NECESSARYPARAMERR, 'errmsg': '缺少必传参数'})
        # 从数据库中提取图形验证码
        # 创建连接到redis的对象
        redis_conn = get_redis_connection('verify_code')
        image_code_server = redis_conn.get('img_%s' % uuid)
        print(image_code_server)
        if image_code_server is None:
            # 图形验证码过期或者不存在
            logger.error('图片过期')
            return http.JsonResponse({'code': RETCODE.IMAGECODEERR, 'errmsg': '图形验证码失效'})
        # 比较验证码
        image_code_server = image_code_server.decode()  # bytes转字符串
        if image_code_client.lower() != image_code_server.lower():  # 转小写后比较
            logger.error('图片错误')
            return http.JsonResponse({'code': RETCODE.IMAGECODEERR, 'errmsg': '输入图形验证码有误'})
        # 生成短信验证码
        sms_code = '%06d' % random.randint(0, 999999)
        logger.info('验证码：%s' % sms_code)
        # 保存短信验证码
        redis_conn.setex('sms_%s' % mobile, constants.SMS_CODE_REDIS_EXPIRES, sms_code)
        # 发送短信验证码
        res = CCP().rest.sendTemplateSMS(mobile, [sms_code, constants.SMS_CODE_REDIS_EXPIRES // 60],
                                constants.SEND_SMS_TEMPLATE_ID)
        print(res)
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '发送短信成功'})